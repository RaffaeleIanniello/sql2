SELECT * FROM Products;

SELECT * FROM Products WHERE UnitsInStock >= 40;


SELECT * FROM Customers WHERE City = 'London';

SELECT * FROM Orders ORDER BY Freight DESC;


SELECT * FROM Orders WHERE Freight > 90 AND Freight < 200;


SELECT * FROM Products WHERE CategoryID = 1;

SELECT * FROM OrderDetails WHERE Discount > 0;

SELECT * FROM Orders WHERE CustomerID = 'BOTTM' AND Freight > 50;